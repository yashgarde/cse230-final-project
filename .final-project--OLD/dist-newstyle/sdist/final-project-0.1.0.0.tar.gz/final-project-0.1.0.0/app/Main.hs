module Main where

import Graphics.Vty
import Brick
import Brick.Widgets.Center
import Brick.Widgets.Border
import Brick.Widgets.Border.Style

main :: IO ()
main = putStrLn "Hello, Haskell!"
